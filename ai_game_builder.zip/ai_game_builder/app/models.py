from sqlalchemy import Column, Integer, String, Text, DateTime, ForeignKey, JSON, Float, Boolean
from sqlalchemy.orm import relationship
from datetime import datetime
from .database import Base


class Project(Base):
    __tablename__ = "projects"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(200), nullable=False)
    description = Column(Text, default="")
    genre = Column(String(100), default="")
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    entities = relationship("Entity", back_populates="project", cascade="all, delete-orphan")
    saves = relationship("PlayerSave", back_populates="project", cascade="all, delete-orphan")
    analytics = relationship("AnalyticsEvent", back_populates="project", cascade="all, delete-orphan")
    generations = relationship("AIGeneration", back_populates="project", cascade="all, delete-orphan")


class Entity(Base):
    """Game entities: items, characters, levels, quests, etc."""
    __tablename__ = "entities"

    id = Column(Integer, primary_key=True, index=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False)
    entity_type = Column(String(100), nullable=False)  # item, character, level, quest, etc.
    name = Column(String(200), nullable=False)
    description = Column(Text, default="")
    data = Column(JSON, default=dict)  # flexible attributes
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    project = relationship("Project", back_populates="entities")


class PlayerSave(Base):
    """Player progress / save data"""
    __tablename__ = "player_saves"

    id = Column(Integer, primary_key=True, index=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False)
    player_name = Column(String(200), nullable=False)
    level = Column(Integer, default=1)
    experience = Column(Integer, default=0)
    inventory = Column(JSON, default=list)
    stats = Column(JSON, default=dict)
    progress = Column(JSON, default=dict)  # quest progress, unlocked areas, etc.
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    project = relationship("Project", back_populates="saves")


class AnalyticsEvent(Base):
    """Playtesting / analytics metrics"""
    __tablename__ = "analytics_events"

    id = Column(Integer, primary_key=True, index=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False)
    event_type = Column(String(100), nullable=False)  # session_start, combat, item_pickup, death, etc.
    session_id = Column(String(100), default="")
    player_id = Column(String(100), default="")
    data = Column(JSON, default=dict)
    value = Column(Float, default=0.0)  # numeric metric if applicable
    created_at = Column(DateTime, default=datetime.utcnow)

    project = relationship("Project", back_populates="analytics")


class AIGeneration(Base):
    """Stored AI generation results"""
    __tablename__ = "ai_generations"

    id = Column(Integer, primary_key=True, index=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=True)
    generation_type = Column(String(50), nullable=False)  # concept, rules, code, asset
    prompt = Column(Text, nullable=False)
    result = Column(Text, nullable=False)
    model = Column(String(100), default="")
    created_at = Column(DateTime, default=datetime.utcnow)

    project = relationship("Project", back_populates="generations")


class CustomSchema(Base):
    """User-defined custom tables / schemas (metadata only)"""
    __tablename__ = "custom_schemas"

    id = Column(Integer, primary_key=True, index=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False)
    table_name = Column(String(100), nullable=False)
    fields = Column(JSON, nullable=False)  # list of {name, type, required}
    description = Column(Text, default="")
    created_at = Column(DateTime, default=datetime.utcnow)

    # Note: actual dynamic data stored in Entity with entity_type = custom_{table_name}
    # or in a generic JSON store for simplicity
