from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from datetime import datetime


# ---------- Project ----------
class ProjectCreate(BaseModel):
    name: str
    description: str = ""
    genre: str = ""


class ProjectUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    genre: Optional[str] = None


class ProjectOut(BaseModel):
    id: int
    name: str
    description: str
    genre: str
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


# ---------- Entity ----------
class EntityCreate(BaseModel):
    project_id: int
    entity_type: str
    name: str
    description: str = ""
    data: Dict[str, Any] = Field(default_factory=dict)


class EntityUpdate(BaseModel):
    entity_type: Optional[str] = None
    name: Optional[str] = None
    description: Optional[str] = None
    data: Optional[Dict[str, Any]] = None


class EntityOut(BaseModel):
    id: int
    project_id: int
    entity_type: str
    name: str
    description: str
    data: Dict[str, Any]
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


# ---------- Player Save ----------
class PlayerSaveCreate(BaseModel):
    project_id: int
    player_name: str
    level: int = 1
    experience: int = 0
    inventory: List[Any] = Field(default_factory=list)
    stats: Dict[str, Any] = Field(default_factory=dict)
    progress: Dict[str, Any] = Field(default_factory=dict)


class PlayerSaveUpdate(BaseModel):
    player_name: Optional[str] = None
    level: Optional[int] = None
    experience: Optional[int] = None
    inventory: Optional[List[Any]] = None
    stats: Optional[Dict[str, Any]] = None
    progress: Optional[Dict[str, Any]] = None


class PlayerSaveOut(BaseModel):
    id: int
    project_id: int
    player_name: str
    level: int
    experience: int
    inventory: List[Any]
    stats: Dict[str, Any]
    progress: Dict[str, Any]
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


# ---------- Analytics ----------
class AnalyticsEventCreate(BaseModel):
    project_id: int
    event_type: str
    session_id: str = ""
    player_id: str = ""
    data: Dict[str, Any] = Field(default_factory=dict)
    value: float = 0.0


class AnalyticsEventOut(BaseModel):
    id: int
    project_id: int
    event_type: str
    session_id: str
    player_id: str
    data: Dict[str, Any]
    value: float
    created_at: datetime

    class Config:
        from_attributes = True


# ---------- AI Generation ----------
class AIGenerateRequest(BaseModel):
    generation_type: str = Field(..., description="concept | rules | code | asset")
    prompt: str
    project_id: Optional[int] = None
    model: str = "openai/gpt-4o-mini"
    system_prompt: Optional[str] = None
    temperature: float = 0.7
    max_tokens: int = 2000


class AIGenerationOut(BaseModel):
    id: int
    project_id: Optional[int]
    generation_type: str
    prompt: str
    result: str
    model: str
    created_at: datetime

    class Config:
        from_attributes = True


# ---------- Custom Schema ----------
class FieldDefinition(BaseModel):
    name: str
    type: str = "string"  # string, integer, float, boolean, json
    required: bool = False
    description: str = ""


class CustomSchemaCreate(BaseModel):
    project_id: int
    table_name: str
    fields: List[FieldDefinition]
    description: str = ""


class CustomSchemaOut(BaseModel):
    id: int
    project_id: int
    table_name: str
    fields: List[Dict[str, Any]]
    description: str
    created_at: datetime

    class Config:
        from_attributes = True
