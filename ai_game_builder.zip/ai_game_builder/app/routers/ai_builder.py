from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from openai import OpenAI
import os
from typing import Optional

from ..database import get_db
from .. import models, schemas

router = APIRouter(prefix="/ai", tags=["AI Game Builder"])


def get_openai_client() -> OpenAI:
    """Create OpenAI-compatible client. Supports OpenRouter and OpenAI."""
    api_key = os.getenv("OPENROUTER_API_KEY") or os.getenv("OPENAI_API_KEY")
    if not api_key:
        raise HTTPException(
            status_code=500,
            detail="No API key found. Set OPENROUTER_API_KEY or OPENAI_API_KEY environment variable."
        )

    base_url = None
    if os.getenv("OPENROUTER_API_KEY"):
        base_url = "https://openrouter.ai/api/v1"

    return OpenAI(api_key=api_key, base_url=base_url)


SYSTEM_PROMPTS = {
    "concept": (
        "You are an expert game designer. Generate a complete, original game concept including: "
        "title, genre, core gameplay loop, unique selling points, target audience, art style suggestions, "
        "and a short narrative premise. Structure the response clearly with headings."
    ),
    "rules": (
        "You are an expert game systems designer. Create detailed, balanced game rules and systems. "
        "Include mechanics for progression, combat (if applicable), economy/resources, win/loss conditions, "
        "and any special systems. Present rules in a clear, structured format that could be used by developers."
    ),
    "code": (
        "You are an expert game programmer. Generate clean, well-commented starter code skeletons "
        "based on the user's request. Prefer Python or JavaScript/TypeScript unless otherwise specified. "
        "Include class/structure definitions, key functions, and brief usage notes. Do not generate full games; "
        "focus on reusable, educational skeletons."
    ),
    "asset": (
        "You are an expert at writing detailed prompts for AI image, audio, and 3D asset generators. "
        "Produce highly descriptive, production-ready prompts that include style, lighting, composition, "
        "mood, technical specifications, and negative prompts where helpful. Offer multiple variations."
    ),
}


@router.post("/generate", response_model=schemas.AIGenerationOut)
def generate_content(
    request: schemas.AIGenerateRequest,
    db: Session = Depends(get_db),
):
    """Generate game content using an OpenAI-compatible API."""
    if request.generation_type not in SYSTEM_PROMPTS:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid generation_type. Must be one of: {list(SYSTEM_PROMPTS.keys())}"
        )

    client = get_openai_client()

    system = request.system_prompt or SYSTEM_PROMPTS[request.generation_type]

    try:
        response = client.chat.completions.create(
            model=request.model,
            messages=[
                {"role": "system", "content": system},
                {"role": "user", "content": request.prompt},
            ],
            temperature=request.temperature,
            max_tokens=request.max_tokens,
        )
        result_text = response.choices[0].message.content or ""
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"AI API error: {str(e)}")

    # Optionally link to project
    project_id = request.project_id
    if project_id:
        project = db.query(models.Project).filter(models.Project.id == project_id).first()
        if not project:
            project_id = None

    generation = models.AIGeneration(
        project_id=project_id,
        generation_type=request.generation_type,
        prompt=request.prompt,
        result=result_text,
        model=request.model,
    )
    db.add(generation)
    db.commit()
    db.refresh(generation)

    return generation


@router.get("/generations", response_model=list[schemas.AIGenerationOut])
def list_generations(
    project_id: Optional[int] = None,
    generation_type: Optional[str] = None,
    limit: int = 50,
    db: Session = Depends(get_db),
):
    query = db.query(models.AIGeneration)
    if project_id is not None:
        query = query.filter(models.AIGeneration.project_id == project_id)
    if generation_type:
        query = query.filter(models.AIGeneration.generation_type == generation_type)
    return query.order_by(models.AIGeneration.created_at.desc()).limit(limit).all()


@router.get("/generations/{generation_id}", response_model=schemas.AIGenerationOut)
def get_generation(generation_id: int, db: Session = Depends(get_db)):
    gen = db.query(models.AIGeneration).filter(models.AIGeneration.id == generation_id).first()
    if not gen:
        raise HTTPException(status_code=404, detail="Generation not found")
    return gen


@router.delete("/generations/{generation_id}")
def delete_generation(generation_id: int, db: Session = Depends(get_db)):
    gen = db.query(models.AIGeneration).filter(models.AIGeneration.id == generation_id).first()
    if not gen:
        raise HTTPException(status_code=404, detail="Generation not found")
    db.delete(gen)
    db.commit()
    return {"ok": True}
