from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List, Optional

from ..database import get_db
from .. import models, schemas

router = APIRouter(prefix="/db", tags=["Database Tracker & Maker"])


# ---------- Projects ----------
@router.post("/projects", response_model=schemas.ProjectOut)
def create_project(project: schemas.ProjectCreate, db: Session = Depends(get_db)):
    db_project = models.Project(**project.model_dump())
    db.add(db_project)
    db.commit()
    db.refresh(db_project)
    return db_project


@router.get("/projects", response_model=List[schemas.ProjectOut])
def list_projects(db: Session = Depends(get_db)):
    return db.query(models.Project).order_by(models.Project.created_at.desc()).all()


@router.get("/projects/{project_id}", response_model=schemas.ProjectOut)
def get_project(project_id: int, db: Session = Depends(get_db)):
    project = db.query(models.Project).filter(models.Project.id == project_id).first()
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    return project


@router.patch("/projects/{project_id}", response_model=schemas.ProjectOut)
def update_project(project_id: int, update: schemas.ProjectUpdate, db: Session = Depends(get_db)):
    project = db.query(models.Project).filter(models.Project.id == project_id).first()
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    for field, value in update.model_dump(exclude_unset=True).items():
        setattr(project, field, value)
    db.commit()
    db.refresh(project)
    return project


@router.delete("/projects/{project_id}")
def delete_project(project_id: int, db: Session = Depends(get_db)):
    project = db.query(models.Project).filter(models.Project.id == project_id).first()
    if not project:
        raise HTTPException(status_code=404, detail="Project not found")
    db.delete(project)
    db.commit()
    return {"ok": True}


# ---------- Entities ----------
@router.post("/entities", response_model=schemas.EntityOut)
def create_entity(entity: schemas.EntityCreate, db: Session = Depends(get_db)):
    # Verify project exists
    if not db.query(models.Project).filter(models.Project.id == entity.project_id).first():
        raise HTTPException(status_code=404, detail="Project not found")
    db_entity = models.Entity(**entity.model_dump())
    db.add(db_entity)
    db.commit()
    db.refresh(db_entity)
    return db_entity


@router.get("/entities", response_model=List[schemas.EntityOut])
def list_entities(
    project_id: Optional[int] = None,
    entity_type: Optional[str] = None,
    db: Session = Depends(get_db),
):
    query = db.query(models.Entity)
    if project_id is not None:
        query = query.filter(models.Entity.project_id == project_id)
    if entity_type:
        query = query.filter(models.Entity.entity_type == entity_type)
    return query.order_by(models.Entity.created_at.desc()).all()


@router.get("/entities/{entity_id}", response_model=schemas.EntityOut)
def get_entity(entity_id: int, db: Session = Depends(get_db)):
    entity = db.query(models.Entity).filter(models.Entity.id == entity_id).first()
    if not entity:
        raise HTTPException(status_code=404, detail="Entity not found")
    return entity


@router.patch("/entities/{entity_id}", response_model=schemas.EntityOut)
def update_entity(entity_id: int, update: schemas.EntityUpdate, db: Session = Depends(get_db)):
    entity = db.query(models.Entity).filter(models.Entity.id == entity_id).first()
    if not entity:
        raise HTTPException(status_code=404, detail="Entity not found")
    for field, value in update.model_dump(exclude_unset=True).items():
        setattr(entity, field, value)
    db.commit()
    db.refresh(entity)
    return entity


@router.delete("/entities/{entity_id}")
def delete_entity(entity_id: int, db: Session = Depends(get_db)):
    entity = db.query(models.Entity).filter(models.Entity.id == entity_id).first()
    if not entity:
        raise HTTPException(status_code=404, detail="Entity not found")
    db.delete(entity)
    db.commit()
    return {"ok": True}


# ---------- Player Saves ----------
@router.post("/saves", response_model=schemas.PlayerSaveOut)
def create_save(save: schemas.PlayerSaveCreate, db: Session = Depends(get_db)):
    if not db.query(models.Project).filter(models.Project.id == save.project_id).first():
        raise HTTPException(status_code=404, detail="Project not found")
    db_save = models.PlayerSave(**save.model_dump())
    db.add(db_save)
    db.commit()
    db.refresh(db_save)
    return db_save


@router.get("/saves", response_model=List[schemas.PlayerSaveOut])
def list_saves(project_id: Optional[int] = None, db: Session = Depends(get_db)):
    query = db.query(models.PlayerSave)
    if project_id is not None:
        query = query.filter(models.PlayerSave.project_id == project_id)
    return query.order_by(models.PlayerSave.updated_at.desc()).all()


@router.get("/saves/{save_id}", response_model=schemas.PlayerSaveOut)
def get_save(save_id: int, db: Session = Depends(get_db)):
    save = db.query(models.PlayerSave).filter(models.PlayerSave.id == save_id).first()
    if not save:
        raise HTTPException(status_code=404, detail="Save not found")
    return save


@router.patch("/saves/{save_id}", response_model=schemas.PlayerSaveOut)
def update_save(save_id: int, update: schemas.PlayerSaveUpdate, db: Session = Depends(get_db)):
    save = db.query(models.PlayerSave).filter(models.PlayerSave.id == save_id).first()
    if not save:
        raise HTTPException(status_code=404, detail="Save not found")
    for field, value in update.model_dump(exclude_unset=True).items():
        setattr(save, field, value)
    db.commit()
    db.refresh(save)
    return save


@router.delete("/saves/{save_id}")
def delete_save(save_id: int, db: Session = Depends(get_db)):
    save = db.query(models.PlayerSave).filter(models.PlayerSave.id == save_id).first()
    if not save:
        raise HTTPException(status_code=404, detail="Save not found")
    db.delete(save)
    db.commit()
    return {"ok": True}


# ---------- Analytics ----------
@router.post("/analytics", response_model=schemas.AnalyticsEventOut)
def create_analytics_event(event: schemas.AnalyticsEventCreate, db: Session = Depends(get_db)):
    if not db.query(models.Project).filter(models.Project.id == event.project_id).first():
        raise HTTPException(status_code=404, detail="Project not found")
    db_event = models.AnalyticsEvent(**event.model_dump())
    db.add(db_event)
    db.commit()
    db.refresh(db_event)
    return db_event


@router.get("/analytics", response_model=List[schemas.AnalyticsEventOut])
def list_analytics(
    project_id: Optional[int] = None,
    event_type: Optional[str] = None,
    limit: int = 100,
    db: Session = Depends(get_db),
):
    query = db.query(models.AnalyticsEvent)
    if project_id is not None:
        query = query.filter(models.AnalyticsEvent.project_id == project_id)
    if event_type:
        query = query.filter(models.AnalyticsEvent.event_type == event_type)
    return query.order_by(models.AnalyticsEvent.created_at.desc()).limit(limit).all()


@router.delete("/analytics/{event_id}")
def delete_analytics_event(event_id: int, db: Session = Depends(get_db)):
    event = db.query(models.AnalyticsEvent).filter(models.AnalyticsEvent.id == event_id).first()
    if not event:
        raise HTTPException(status_code=404, detail="Event not found")
    db.delete(event)
    db.commit()
    return {"ok": True}


# ---------- Custom Schemas ----------
@router.post("/schemas", response_model=schemas.CustomSchemaOut)
def create_custom_schema(schema: schemas.CustomSchemaCreate, db: Session = Depends(get_db)):
    if not db.query(models.Project).filter(models.Project.id == schema.project_id).first():
        raise HTTPException(status_code=404, detail="Project not found")
    # Store fields as list of dicts
    fields_data = [f.model_dump() for f in schema.fields]
    db_schema = models.CustomSchema(
        project_id=schema.project_id,
        table_name=schema.table_name,
        fields=fields_data,
        description=schema.description,
    )
    db.add(db_schema)
    db.commit()
    db.refresh(db_schema)
    return db_schema


@router.get("/schemas", response_model=List[schemas.CustomSchemaOut])
def list_custom_schemas(project_id: Optional[int] = None, db: Session = Depends(get_db)):
    query = db.query(models.CustomSchema)
    if project_id is not None:
        query = query.filter(models.CustomSchema.project_id == project_id)
    return query.all()


@router.get("/schemas/{schema_id}", response_model=schemas.CustomSchemaOut)
def get_custom_schema(schema_id: int, db: Session = Depends(get_db)):
    schema = db.query(models.CustomSchema).filter(models.CustomSchema.id == schema_id).first()
    if not schema:
        raise HTTPException(status_code=404, detail="Schema not found")
    return schema


@router.delete("/schemas/{schema_id}")
def delete_custom_schema(schema_id: int, db: Session = Depends(get_db)):
    schema = db.query(models.CustomSchema).filter(models.CustomSchema.id == schema_id).first()
    if not schema:
        raise HTTPException(status_code=404, detail="Schema not found")
    db.delete(schema)
    db.commit()
    return {"ok": True}
