# AI Game Builder & Database Tracker

A web application built with **FastAPI** that combines:

- **AI-assisted game design tools** (concept generation, rules & systems, code skeletons, asset prompts)
- **Full database tracker and maker** (projects, game entities, player saves, analytics events, custom schemas)

The interface is mobile-friendly and works in any modern phone browser once the application is deployed.

## Features

### AI Game Builder
- Generate game concepts, rules/systems, code skeletons, and detailed asset prompts
- Configurable model, temperature, and optional linkage to a project
- Full history of generations

### Database Tracker & Maker
- **Projects** – organize work by game
- **Entities** – flexible records for items, characters, levels, quests, etc. (JSON attributes)
- **Player Saves** – track progress, inventory, stats
- **Analytics** – log and review playtesting / telemetry events
- **Custom Schemas** – define your own table structures (metadata)

## Quick Start (Local Computer)

```bash
python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt

export OPENROUTER_API_KEY="your-key-here"   # or OPENAI_API_KEY
uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```

Open http://127.0.0.1:8000 in your browser.

## Deploy so you can use it on your phone

To access the app from a phone browser you need a public URL. Below are the easiest free options.

### Option 1 – Render.com (Recommended, free tier)

1. Create a free account at https://render.com
2. Click **New → Web Service**
3. Connect your GitHub repository (or upload the code)
4. Configure the service:
   - **Runtime**: Python
   - **Build Command**: `pip install -r requirements.txt`
   - **Start Command**: `uvicorn app.main:app --host 0.0.0.0 --port $PORT`
5. Add an Environment Variable:
   - Key: `OPENROUTER_API_KEY` (or `OPENAI_API_KEY`)
   - Value: your actual API key
6. Click **Create Web Service**

After a few minutes Render will give you a public URL such as  
`https://ai-game-builder-xxxx.onrender.com`  
Open that link on your phone.

### Option 2 – Railway.app

1. Create an account at https://railway.app
2. New Project → Deploy from GitHub (or upload)
3. Add the environment variable `OPENROUTER_API_KEY`
4. Railway will detect the Dockerfile automatically and deploy
5. Generate a public domain in the settings

### Option 3 – Docker (any host)

```bash
docker build -t ai-game-builder .
docker run -p 8000:8000 -e OPENROUTER_API_KEY="your-key" ai-game-builder
```

## Important Notes for Phone / Public Use

- The free tiers of Render and Railway may spin down after inactivity. The first request after idle time can take 30–60 seconds.
- SQLite is used for simplicity. On free platforms the database file is ephemeral (it resets when the service restarts). For permanent storage you would later switch to a managed Postgres database.
- Never share your API key. It is read only from environment variables.
- The current version has no user login. Anyone with the public URL can use the app and see the data. For personal use this is usually fine; add authentication later if needed.

## Project Structure

```
ai_game_builder/
├── app/
│   ├── main.py
│   ├── database.py
│   ├── models.py
│   ├── schemas.py
│   └── routers/
├── templates/
│   └── index.html          # Mobile-friendly UI
├── Dockerfile
├── requirements.txt
└── README.md
```

## Security

- API keys are never stored in the code or database.
- CORS is enabled so the interface works when served from a public domain.
- For production use with sensitive data, add authentication and switch to a proper database.
